<template>
  <!-- component -->
  <!-- Display Container (not part of component) START -->
  <div class="mx-auto p-16 sm:p-24 lg:p-48 bg-gray-200">
    <!-- Carousel Body -->
    <div
      class="
        relative
        rounded-lg
        block
        md:flex
        items-center
        bg-gray-100
        shadow-xl
      "
      style="min-height: 19rem"
    >
      <div
        class="
          relative
          w-full
          md:w-2/5
          h-full
          overflow-hidden
          rounded-t-lg
          md:rounded-t-none md:rounded-l-lg
        "
        style="min-height: 19rem"
      >
        <img
          class="absolute inset-0 w-full h-full object-cover object-center"
          :src="false || './images/default.svg'"
          alt=""
        />
        <div
          class="absolute inset-0 w-full h-full bg-indigo-900 opacity-75"
        ></div>
        <div
          class="
            absolute
            inset-0
            w-full
            h-full
            flex
            items-center
            justify-center
            fill-current
            text-white
          "
        >
          <p>{{ selectedTestPackage }}</p>
        </div>
      </div>
      <div
        class="w-full md:w-3/5 h-full flex items-center bg-gray-100 rounded-lg"
      >
        <div class="p-12 md:pr-24 md:pl-16 md:py-12">
          <p class="text-gray-600">{{ selectedTestPackage }}</p>
          <a
            class="
              flex
              items-baseline
              mt-3
              text-indigo-600
              hover:text-indigo-900
              focus:text-indigo-900
            "
            href=""
          >
            <span>Entrar ahora.</span>
            <span class="text-xs ml-1">&#x279c;</span>
          </a>
        </div>
        <svg
          class="
            hidden
            md:block
            absolute
            inset-y-0
            h-full
            w-24
            fill-current
            text-gray-100
            -ml-12
          "
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
        >
          <polygon points="50,0 100,0 50,100 0,100" />
        </svg>
      </div>
      <button
        @click.prevent="prevTestPackage()"
        class="
          absolute
          top-0
          mt-32
          left-0
          bg-white
          rounded-full
          shadow-md
          h-12
          w-12
          text-2xl text-indigo-600
          hover:text-indigo-400
          focus:text-indigo-400
          -ml-6
          focus:outline-none
          focus:shadow-outline
        "
      >
        <span class="block" style="transform: scale(-1)">&#x279c;</span>
      </button>
      <button
        @click.prevent="nextTestPackage()"
        class="
          absolute
          top-0
          mt-32
          right-0
          bg-white
          rounded-full
          shadow-md
          h-12
          w-12
          text-2xl text-indigo-600
          hover:text-indigo-400
          focus:text-indigo-400
          -mr-6
          focus:outline-none
          focus:shadow-outline
        "
      >
        <span class="block" style="transform: scale(1)">&#x279c;</span>
      </button>
    </div>

    <!-- Carousel Tabs -->
  </div>
  <!-- Display Container (not part of component) END -->
</template>
<script>
import { useStore } from "vuex";
import { computed, ref, onMounted } from "vue";

export default {
  setup() {
    const store = useStore();
    let SelectedTestPackageCounter, selectedTestPackage, tests;
    store.dispatch("test/getAllTestPackages").then(() => {
      SelectedTestPackageCounter = ref(0);
      selectedTestPackage = computed(() => store.state.test.allTestPackages);
      // selectedTestPackages = computed(
      //   () => tests[SelectedTestPackageCounter.value]
      // );
    });

    const prevTestPackage = () => {
      if (SelectedTestPackageCounter.value > 0) {
        SelectedTestPackageCounter.value--;
      }
    };
    const nextTestPackage = () => {
      if (
        store.state.test.allTestPackages.length >=
        SelectedTestPackageCounter.value
      ) {
        SelectedTestPackageCounter.value++;
      }
    };

    // let selectedTestPackage = computed(()=> allTestPackages[SelectedTestPackageCounter])

    return {
      tests,
      selectedTestPackage,
      prevTestPackage,
      nextTestPackage,
      SelectedTestPackageCounter,
    };
  },
};
</script>
