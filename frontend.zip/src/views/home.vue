<template lang="pug">
navBar
carrousel

</template>
<script>
import navBar from "../components/navbar.vue";
import carrousel from "../components/carrousel.vue";
import { computed, onMounted } from "vue";
import { useStore } from "vuex";
export default {
  components: {
    carrousel,
    navBar,
  },
  setup() {
    const store = useStore();
    // onMounted(async () => {
      
    // });
  },
};
</script>
